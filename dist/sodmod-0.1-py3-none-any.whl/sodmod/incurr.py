def Id(t):
    if   0.0  < t < 20.0:    return 0
    elif 20.0 < t < 100.0:   return 50
#     elif 15.0 < t < 25.0: return 10
    
    return 0.0